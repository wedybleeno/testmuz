import {start} from "telebot-vercel"
import bot from "../src/bot.mjs"

export default start({bot})
